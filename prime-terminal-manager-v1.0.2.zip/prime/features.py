"""PRIME TERMINAL MANAGER v1.0.2 — toolkit features.

Ten extra tools built on the same rules as the rest of the panel: every value
comes from the real system (/proc, statvfs, ssl, crontab, du ...), every
command is run as an argument array (never through a shell string built from
user input), and every write is audited.

Python 3.8 compatible: no ``match``, no ``X | Y`` annotations, no builtin
generics in annotations.
"""
from __future__ import annotations

import asyncio
import json
import os
import re
import shutil
import socket
import ssl
import threading
import time
from typing import Any, Dict, List, Optional

from . import ops, security, sysinfo
from .config import Config
from .jobs import JobManager

MAX_SNIPPETS = 200
MAX_NOTES_BYTES = 200 * 1024
USER_RE = re.compile(r"^[a-z_][a-z0-9_-]{0,31}$")
HOST_RE = re.compile(r"^[A-Za-z0-9.-]{1,253}$")

DEFAULT_THRESHOLDS = {"cpu": 85.0, "memory": 90.0, "disk": 90.0, "load_per_core": 1.5}


class FeatureError(Exception):
    def __init__(self, message: str, code: int = 400) -> None:
        super().__init__(message)
        self.message = message
        self.code = code


class ToolkitStore:
    """Small JSON store for snippets, notes and alert thresholds (atomic writes)."""

    def __init__(self, cfg: Config) -> None:
        self.path = os.path.join(cfg.data_dir, "toolkit.json")
        self._lock = threading.Lock()

    def _read(self) -> Dict[str, Any]:
        try:
            with open(self.path, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            if isinstance(data, dict):
                return data
        except (OSError, ValueError):
            pass
        return {}

    def _write(self, data: Dict[str, Any]) -> None:
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(data, fh, indent=2)
        os.chmod(tmp, 0o600)
        os.replace(tmp, self.path)

    def get(self, key: str, default: Any) -> Any:
        with self._lock:
            return self._read().get(key, default)

    def update(self, key: str, fn) -> Any:
        with self._lock:
            data = self._read()
            value = fn(data.get(key))
            data[key] = value
            self._write(data)
            return value


# ----------------------------------------------------------------- 1. snippets
def list_snippets(store: ToolkitStore) -> Dict[str, Any]:
    return {"items": store.get("snippets", [])}


def save_snippet(store: ToolkitStore, title: str, command: str, notes: str = "") -> Dict[str, Any]:
    title = title.strip()
    command = command.strip()
    if not title or not command:
        raise FeatureError("title and command are required")
    if len(command) > 4000:
        raise FeatureError("command is too long (4000 characters max)")

    def mutate(items: Optional[List[Dict[str, Any]]]) -> List[Dict[str, Any]]:
        items = list(items or [])
        if len(items) >= MAX_SNIPPETS:
            raise FeatureError("snippet limit reached")
        items.append({"id": "%08x" % (int(time.time() * 1000) & 0xFFFFFFFF),
                      "title": title[:80], "command": command, "notes": notes[:300],
                      "created": time.time()})
        return items

    items = store.update("snippets", mutate)
    return items[-1]


def delete_snippet(store: ToolkitStore, snippet_id: str) -> bool:
    def mutate(items: Optional[List[Dict[str, Any]]]) -> List[Dict[str, Any]]:
        return [i for i in (items or []) if i.get("id") != snippet_id]

    before = store.get("snippets", [])
    after = store.update("snippets", mutate)
    return len(after) != len(before)


async def run_snippet(store: ToolkitStore, jobs: JobManager, snippet_id: str) -> Dict[str, Any]:
    snippet = next((i for i in store.get("snippets", []) if i.get("id") == snippet_id), None)
    if not snippet:
        raise FeatureError("no such snippet", 404)
    job = await jobs.start("snippet: " + snippet["title"], ["bash", "-c", snippet["command"]])
    return {"job_id": job.id, "label": job.label}


# ------------------------------------------------------------------ 2. alerts
def get_thresholds(store: ToolkitStore) -> Dict[str, float]:
    saved = store.get("thresholds", {}) or {}
    out = dict(DEFAULT_THRESHOLDS)
    for key in DEFAULT_THRESHOLDS:
        try:
            out[key] = float(saved.get(key, out[key]))
        except (TypeError, ValueError):
            pass
    return out


def set_thresholds(store: ToolkitStore, values: Dict[str, Any]) -> Dict[str, float]:
    clean = {}
    for key, default in DEFAULT_THRESHOLDS.items():
        try:
            value = float(values.get(key, default))
        except (TypeError, ValueError):
            raise FeatureError(f"{key} must be a number")
        if not 0 < value <= 100 * (10 if key == "load_per_core" else 1):
            raise FeatureError(f"{key} is out of range")
        clean[key] = value
    store.update("thresholds", lambda _old: clean)
    return clean


def evaluate_alerts(store: ToolkitStore) -> Dict[str, Any]:
    limits = get_thresholds(store)
    cpu = sysinfo.cpu_info()
    mem = sysinfo.memory_info()
    root = (sysinfo.disk_info().get("root") or {})
    load = sysinfo.load_average()
    cores = max(1, cpu.get("logical_cores") or 1)

    checks = [
        ("cpu", "CPU usage", float(cpu.get("usage_percent") or 0), limits["cpu"], "%"),
        ("memory", "Memory used", float(mem.get("percent") or 0), limits["memory"], "%"),
        ("disk", "Root disk used", float(root.get("percent") or 0), limits["disk"], "%"),
        ("load_per_core", "Load per core (1 min)",
         round(float(load.get("1m", 0)) / cores, 2), limits["load_per_core"], ""),
    ]
    alerts = []
    for key, label, value, limit, unit in checks:
        if value >= limit:
            severity = "critical" if value >= limit * 1.05 else "warning"
            alerts.append({"key": key, "label": label, "value": value, "limit": limit,
                           "unit": unit, "severity": severity})
    return {"ok": not alerts, "alerts": alerts, "thresholds": limits,
            "checked_at": time.time()}


# ------------------------------------------------------- 3. markdown report
def build_report(cfg: Config, panel_version: str) -> str:
    snap = sysinfo.snapshot()
    alerts = evaluate_alerts(ToolkitStore(cfg))
    os_i = snap["os"]
    cpu = snap["cpu"]
    mem = snap["memory"]
    root = (snap["disk"].get("root") or {})
    lines = [
        "# PRIME TERMINAL MANAGER — system report",
        "",
        f"- Generated: {time.strftime('%Y-%m-%d %H:%M:%S %Z')}",
        f"- Panel version: {panel_version}",
        f"- Host: {snap.get('hostname', '')}",
        f"- OS: {os_i.get('distro', '')} · kernel {os_i.get('kernel', '')} · {os_i.get('arch', '')}",
        f"- Uptime: {int(os_i.get('uptime_seconds') or 0)} s",
        f"- CPU: {cpu.get('logical_cores', '?')} cores · usage {cpu.get('usage_percent', 0)}%",
        f"- Memory: {mem.get('used', 0)} of {mem.get('total', 0)} bytes used ({mem.get('percent', 0)}%)",
        f"- Root disk: {root.get('percent', 0)}% used",
        "",
        "## Health alerts",
    ]
    if alerts["alerts"]:
        for a in alerts["alerts"]:
            lines.append(f"- [{a['severity']}] {a['label']}: {a['value']}{a['unit']} "
                         f"(limit {a['limit']}{a['unit']})")
    else:
        lines.append("- No alerts. All thresholds are within limits.")
    lines += ["", "## Listening ports", "", "| protocol | address | port | process |",
              "|---|---|---|---|"]
    for row in sysinfo.listening_ports().get("items", [])[:200]:
        lines.append(f"| {row['protocol']} | {row['address']} | {row['port']} | "
                     f"{row.get('process') or 'hidden'} |")
    lines.append("")
    return "\n".join(lines)


# ------------------------------------------------------------ 4. port finder
def find_port(port: int) -> Dict[str, Any]:
    if not 1 <= port <= 65535:
        raise FeatureError("port must be between 1 and 65535")
    matches = [r for r in sysinfo.listening_ports().get("items", []) if r["port"] == port]
    return {"port": port, "items": matches, "in_use": bool(matches)}


# ------------------------------------------------------------ 5. crontab
async def read_crontab(user: str, is_root: bool) -> Dict[str, Any]:
    if user and not USER_RE.match(user):
        raise FeatureError("invalid user name")
    argv = ["crontab", "-l"]
    if user:
        if not is_root:
            raise FeatureError("viewing another user's crontab requires root", 403)
        argv += ["-u", user]
    res = await ops.run(argv, timeout=10)
    text = res["stdout"] if res["ok"] else ""
    note = "" if res["ok"] else (res["stderr"].strip() or "no crontab for this user")
    return {"user": user or "(current)", "content": text, "note": note}


# -------------------------------------------------------- 6. SSL expiry
def _check_cert(host: str, port: int) -> Dict[str, Any]:
    ctx = ssl.create_default_context()
    started = time.time()
    try:
        with socket.create_connection((host, port), timeout=6) as sock:
            with ctx.wrap_socket(sock, server_hostname=host) as tls:
                cert = tls.getpeercert()
                tls_version = tls.version()
    except ssl.SSLCertVerificationError as exc:
        return {"ok": False, "host": host, "port": port, "error": f"certificate rejected: {exc.verify_message}"}
    except (OSError, ssl.SSLError) as exc:
        return {"ok": False, "host": host, "port": port, "error": str(exc) or exc.__class__.__name__}
    not_after = ssl.cert_time_to_seconds(cert["notAfter"])
    days = int((not_after - time.time()) // 86400)
    subject = dict(x[0] for x in cert.get("subject", ()))
    issuer = dict(x[0] for x in cert.get("issuer", ()))
    return {"ok": True, "host": host, "port": port, "tls": tls_version,
            "subject": subject.get("commonName", ""), "issuer": issuer.get("organizationName", ""),
            "expires": cert["notAfter"], "days_left": days,
            "status": "expired" if days < 0 else "critical" if days < 7
            else "warning" if days < 30 else "ok", "elapsed": round(time.time() - started, 2)}


async def check_certificate(host: str, port: int) -> Dict[str, Any]:
    host = host.strip().lower()
    if not HOST_RE.match(host):
        raise FeatureError("invalid host name")
    if not 1 <= port <= 65535:
        raise FeatureError("port must be between 1 and 65535")
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, _check_cert, host, port)


# ------------------------------------------------------- 7. disk hogs
async def largest_dirs(cfg: Config, requested: str, top: int = 15) -> Dict[str, Any]:
    try:
        path = security.safe_path(requested or "/", cfg.allowed_roots, must_exist=True)
    except security.PathError as exc:
        raise FeatureError(str(exc), 403)
    if not os.path.isdir(path):
        raise FeatureError("not a directory")
    res = await ops.run(["du", "-x", "-k", "-d", "1", path], timeout=60)
    rows = []
    for line in res["stdout"].splitlines():
        parts = line.split("\t", 1)
        if len(parts) != 2:
            continue
        try:
            kib = int(parts[0])
        except ValueError:
            continue
        if parts[1].rstrip("/") == path.rstrip("/"):
            continue
        rows.append({"path": parts[1], "bytes": kib * 1024})
    rows.sort(key=lambda r: -r["bytes"])
    return {"path": path, "items": rows[:top], "ok": res["ok"],
            "note": "" if res["ok"] else (res["stderr"].strip()[:300] or "du failed")}


# --------------------------------------------------------- 8. recent logins
async def recent_logins() -> Dict[str, Any]:
    if not shutil.which("last"):
        return {"items": [], "note": "the 'last' command is not installed"}
    res = await ops.run(["last", "-n", "25", "-w"], timeout=10)
    lines = [ln for ln in res["stdout"].splitlines() if ln.strip() and not ln.startswith("wtmp")]
    return {"items": lines[:25], "note": ""}


# -------------------------------------------------------- 9. time sync
async def time_sync() -> Dict[str, Any]:
    if not shutil.which("timedatectl"):
        return {"available": False, "note": "timedatectl is not available on this system",
                "local_time": time.strftime("%Y-%m-%d %H:%M:%S %Z")}
    res = await ops.run(["timedatectl", "show"], timeout=10)
    info = {}
    for line in res["stdout"].splitlines():
        if "=" in line:
            k, v = line.split("=", 1)
            info[k] = v
    return {"available": True, "timezone": info.get("Timezone", ""),
            "ntp_synchronized": info.get("NTPSynchronized", "") == "yes",
            "ntp_service": info.get("NTP", ""), "local_time": info.get("TimeUSec", ""),
            "rtc_in_local_tz": info.get("LocalRTC", "") == "yes"}


# ------------------------------------------------------- 10. runbook notes
def get_notes(store: ToolkitStore) -> Dict[str, Any]:
    text = store.get("notes", "") or ""
    return {"text": text, "updated": store.get("notes_updated", None)}


def set_notes(store: ToolkitStore, text: str) -> Dict[str, Any]:
    if len(text.encode("utf-8")) > MAX_NOTES_BYTES:
        raise FeatureError("notes are too large (200 KB max)")
    store.update("notes", lambda _old: text)
    store.update("notes_updated", lambda _old: time.time())
    return {"ok": True}
