"""Server management operations: services, packages, logs, diagnostics,
Python execution and SSH keys.

Everything here shells out to the real system tools. When a tool or the
required privilege is missing the operation reports that honestly instead of
pretending to succeed.
"""
from __future__ import annotations

import asyncio
import os
import pwd
import re
import shutil
import tempfile
import time
from typing import Any, Dict, List, Optional

from . import security, sysinfo
from .config import Config
from .jobs import JobManager


class OpError(Exception):
    def __init__(self, message: str, code: int = 400) -> None:
        super().__init__(message)
        self.message = message
        self.code = code


async def run(argv: List[str], timeout: float = 20.0, stdin: Optional[bytes] = None,
              cwd: Optional[str] = None, env: Optional[dict] = None) -> Dict[str, Any]:
    full_env = dict(os.environ)
    full_env.update({"LC_ALL": "C.UTF-8", "LANG": "C.UTF-8", "TERM": "dumb"})
    if env:
        full_env.update(env)
    started = time.time()
    try:
        proc = await asyncio.create_subprocess_exec(
            *argv, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
            stdin=asyncio.subprocess.PIPE if stdin else asyncio.subprocess.DEVNULL,
            cwd=cwd, env=full_env)
    except FileNotFoundError:
        return {"ok": False, "command": argv, "stdout": "", "stderr": f"command not found: {argv[0]}",
                "code": 127, "duration": 0.0}
    except PermissionError as exc:
        return {"ok": False, "command": argv, "stdout": "", "stderr": str(exc), "code": 126,
                "duration": 0.0}
    try:
        out, err = await asyncio.wait_for(proc.communicate(stdin), timeout=timeout)
        code = proc.returncode
    except asyncio.TimeoutError:
        proc.kill()
        out, err = await proc.communicate()
        return {"ok": False, "command": argv, "stdout": out.decode("utf-8", "replace"),
                "stderr": f"timed out after {timeout}s", "code": 124,
                "duration": round(time.time() - started, 2)}
    return {
        "ok": code == 0,
        "command": argv,
        "stdout": out.decode("utf-8", "replace"),
        "stderr": err.decode("utf-8", "replace"),
        "code": code,
        "duration": round(time.time() - started, 2),
    }


# ---------------------------------------------------------------------------
# Services
# ---------------------------------------------------------------------------
def service_backend() -> Dict[str, Any]:
    if os.path.isdir("/run/systemd/system") and shutil.which("systemctl"):
        return {"kind": "systemd", "tool": "systemctl", "actions": True}
    if shutil.which("rc-service"):
        return {"kind": "openrc", "tool": "rc-service", "actions": True}
    if shutil.which("service"):
        return {"kind": "sysvinit", "tool": "service", "actions": True}
    return {"kind": "none", "tool": None, "actions": False,
            "note": "No supported service manager was found in this environment "
                    "(containers usually run without systemd)."}


async def list_services() -> Dict[str, Any]:
    backend = service_backend()
    items: List[Dict[str, Any]] = []
    if backend["kind"] == "systemd":
        res = await run(["systemctl", "list-units", "--type=service", "--all", "--no-legend",
                         "--no-pager", "--plain", "--full"], timeout=15)
        if res["ok"]:
            for line in res["stdout"].splitlines():
                parts = line.split(None, 4)
                if len(parts) < 4 or not parts[0].endswith(".service"):
                    continue
                items.append({
                    "name": parts[0],
                    "load": parts[1],
                    "active": parts[2],
                    "sub": parts[3],
                    "description": (parts[4] if len(parts) > 4 else "").strip(),
                })
        else:
            backend["error"] = res["stderr"].strip() or "systemctl failed"
        # enabled/disabled state in one extra call
        try:
            unit_files = await run(["systemctl", "list-unit-files", "--type=service",
                                    "--no-legend", "--no-pager", "--plain"], timeout=15)
            enabled = {}
            if unit_files["ok"]:
                for line in unit_files["stdout"].splitlines():
                    parts = line.split()
                    if len(parts) >= 2:
                        enabled[parts[0]] = parts[1]
            for item in items:
                item["enabled"] = enabled.get(item["name"], "unknown")
        except Exception:
            pass
    elif backend["kind"] in ("openrc", "sysvinit"):
        if shutil.which("rc-status"):
            res = await run(["rc-status", "-a", "-s"], timeout=15)
            if res["ok"]:
                for line in res["stdout"].splitlines():
                    line = line.strip()
                    if line and "[" in line and "]" in line:
                        name = line.split("[")[0].strip()
                        state = line.split("[")[1].rstrip("]").strip()
                        items.append({"name": name, "active": state, "sub": state,
                                      "description": "", "load": "loaded", "enabled": "unknown"})
        elif shutil.which("service"):
            res = await run(["service", "--status-all"], timeout=15)
            for line in res["stdout"].splitlines():
                m = re.match(r"\s*\[\s*([+?-])\s*\]\s+(\S+)", line)
                if m:
                    state = {"+": "running", "-": "stopped", "?": "unknown"}[m.group(1)]
                    items.append({"name": m.group(2), "active": state, "sub": state,
                                  "description": "", "load": "loaded", "enabled": "unknown"})
    if items:
        order = {"active": 0, "reloading": 1, "activating": 2, "failed": 3, "inactive": 4}
        items.sort(key=lambda i: (order.get(i["active"], 5), i["name"]))
    return {"backend": backend, "items": items, "can_manage": backend["actions"],
            "can_control": os.geteuid() == 0 or shutil.which("sudo") is not None}


async def service_action(name: str, action: str, jobs: JobManager) -> Dict[str, Any]:
    if not security.valid_service_name(name):
        raise OpError("invalid service name", 400)
    backend = service_backend()
    if not backend["actions"]:
        raise OpError("no service manager available in this environment", 501)
    allowed = {"start", "stop", "restart", "reload", "enable", "disable", "status"}
    if action not in allowed:
        raise OpError("unsupported action", 400)
    if backend["kind"] == "systemd":
        argv = ["systemctl", action, name]
    elif backend["kind"] == "openrc":
        argv = ["rc-service", name, action] if action in ("start", "stop", "restart", "status") \
            else ["rc-update", "add" if action == "enable" else "del", name]
    else:
        argv = ["service", name, action]
    if os.geteuid() != 0 and action not in ("status",):
        sudo = shutil.which("sudo")
        if not sudo:
            raise OpError("this action needs root and sudo is not available", 403)
        argv = [sudo, "-n"] + argv
    job = await jobs.start(f"service {action} {name}", argv)
    return {"job": job.public()}


async def service_logs(name: str, lines: int = 200) -> Dict[str, Any]:
    if not security.valid_service_name(name):
        raise OpError("invalid service name", 400)
    lines = max(10, min(2000, lines))
    if not shutil.which("journalctl"):
        raise OpError("journalctl is not available; use the file log viewer instead", 501)
    argv = ["journalctl", "-u", name, "-n", str(lines), "--no-pager", "--output=short-iso"]
    if os.geteuid() != 0:
        argv.append("--user-unit" if False else "--no-hostname")
        if not shutil.which("sudo"):
            raise OpError("journal access usually requires root or the systemd-journal group", 403)
        argv = ["sudo", "-n"] + argv
    res = await run(argv, timeout=20)
    return {"name": name, "result": res, "supported": True}


# ---------------------------------------------------------------------------
# Package management
# ---------------------------------------------------------------------------
def package_backend() -> Dict[str, Any]:
    for name, probe, tools in (
            ("apt", "apt-get", ("apt-cache", "dpkg-query", "apt-get")),
            ("dnf", "dnf", ("dnf", "rpm")),
            ("yum", "yum", ("yum", "rpm")),
            ("pacman", "pacman", ("pacman",)),
            ("apk", "apk", ("apk",))):
        if shutil.which(probe):
            if all(shutil.which(t) for t in tools):
                return {"kind": name, "ok": True, "tools": list(tools)}
            return {"kind": name, "ok": False,
                    "note": f"{name} detected but some tools are missing: "
                            + ", ".join(t for t in tools if not shutil.which(t))}
    return {"kind": "none", "ok": False, "note": "no supported package manager found"}


async def package_search(query: str) -> Dict[str, Any]:
    q = (query or "").strip()
    if not q or not security.valid_package_name(q):
        raise OpError("invalid search query", 400)
    backend = package_backend()
    items = []
    if backend["kind"] == "apt":
        res = await run(["apt-cache", "search", "--names-only", q], timeout=25)
        for line in res["stdout"].splitlines():
            if " - " in line:
                name, desc = line.split(" - ", 1)
                items.append({"name": name.strip(), "description": desc.strip(),
                              "installed": None})
        # mark installed
        inst = await run(["dpkg-query", "-W", "-f=${Package}\t${Status}\n"], timeout=20)
        installed = {line.split("\t")[0] for line in inst["stdout"].splitlines()
                     if "install ok installed" in line}
        for item in items:
            item["installed"] = item["name"] in installed
    elif backend["kind"] in ("dnf", "yum"):
        res = await run([backend["kind"], "search", "-q", q], timeout=40)
        for line in res["stdout"].splitlines():
            if " : " in line and not line.startswith(" "):
                name, desc = line.split(" : ", 1)
                items.append({"name": name.strip(), "description": desc.strip()})
    elif backend["kind"] == "pacman":
        res = await run(["pacman", "-Ss", q], timeout=30)
        lines = res["stdout"].splitlines()
        for i in range(0, len(lines) - 1, 2):
            if "/" in lines[i]:
                items.append({"name": lines[i].split()[0].split("/", 1)[1],
                              "description": lines[i + 1].strip()})
    elif backend["kind"] == "apk":
        res = await run(["apk", "search", "-v", q], timeout=30)
        for line in res["stdout"].splitlines():
            if " - " in line:
                name, desc = line.split(" - ", 1)
                items.append({"name": name.strip(), "description": desc.strip()})
    return {"backend": backend, "query": q, "items": items[:200],
            "raw": res["stdout"][:4000] if not items else "",
            "stderr": res["stderr"][:2000],
            "root": os.geteuid() == 0}


async def package_list_installed(limit: int = 400) -> Dict[str, Any]:
    backend = package_backend()
    items = []
    if backend["kind"] == "apt":
        res = await run(["dpkg-query", "-W", "-f=${Package}\t${Version}\t${Installed-Size}\n"],
                        timeout=25)
        for line in res["stdout"].splitlines():
            parts = line.split("\t")
            if len(parts) >= 2:
                items.append({"name": parts[0], "version": parts[1],
                              "size_kb": int(parts[2]) if len(parts) > 2 and parts[2].isdigit() else None})
    elif backend["kind"] in ("dnf", "yum"):
        res = await run(["rpm", "-qa", "--qf", "%{NAME}\t%{VERSION}-%{RELEASE}\t%{SIZE}\n"],
                        timeout=30)
        for line in res["stdout"].splitlines():
            parts = line.split("\t")
            if len(parts) >= 2:
                items.append({"name": parts[0], "version": parts[1],
                              "size_kb": int(parts[2]) // 1024 if len(parts) > 2 and parts[2].isdigit() else None})
    elif backend["kind"] == "pacman":
        res = await run(["pacman", "-Q"], timeout=25)
        for line in res["stdout"].splitlines():
            parts = line.split()
            if len(parts) >= 2:
                items.append({"name": parts[0], "version": parts[1]})
    elif backend["kind"] == "apk":
        res = await run(["apk", "info", "-v"], timeout=25)
        for line in res["stdout"].splitlines():
            if "-" in line:
                items.append({"name": line.strip(), "version": ""})
    items.sort(key=lambda i: i["name"])
    return {"backend": backend, "items": items[:limit], "total": len(items),
            "root": os.geteuid() == 0}


async def package_install(names: List[str], action: str, jobs: JobManager) -> Dict[str, Any]:
    if not names:
        raise OpError("no packages given", 400)
    for name in names:
        if not security.valid_package_name(name):
            raise OpError(f"invalid package name: {name}", 400)
    backend = package_backend()
    if not backend["ok"]:
        raise OpError(backend.get("note", "no package manager"), 501)
    if os.geteuid() != 0 and not shutil.which("sudo"):
        raise OpError("installing packages requires root and sudo is not available", 403)
    kind = backend["kind"]
    if kind == "apt":
        verb = {"install": "install", "remove": "remove", "upgrade": "upgrade"}[action]
        argv = ["apt-get", verb, "-y"]
        if action != "upgrade":
            argv += ["--"] + names if False else names
    elif kind in ("dnf", "yum"):
        verb = {"install": "install", "remove": "remove", "upgrade": "upgrade"}[action]
        argv = [kind, verb, "-y"] + (names if action != "upgrade" else [])
    elif kind == "pacman":
        verb = {"install": "-S", "remove": "-R", "upgrade": "-Syu"}[action]
        argv = ["pacman", verb, "--noconfirm"] + (names if action != "upgrade" else [])
    else:
        verb = {"install": "add", "remove": "del", "upgrade": "upgrade"}[action]
        argv = ["apk", verb, "-y"] + (names if action != "upgrade" else [])
    job = await jobs.start(f"package {action}: {' '.join(names) or 'all'}", argv, use_sudo=True)
    return {"job": job.public()}


# ---------------------------------------------------------------------------
# Logs
# ---------------------------------------------------------------------------
def log_sources(cfg: Config) -> Dict[str, Any]:
    files = []
    seen = set()
    for base in cfg.extra_log_dirs:
        real = os.path.realpath(base)
        if not os.path.isdir(real):
            continue
        try:
            for name in sorted(os.listdir(real)):
                full = os.path.join(real, name)
                if not os.path.isfile(full) or os.path.islink(full):
                    continue
                if name.endswith((".gz", ".xz", ".bz2", ".zst", ".1", ".old")):
                    continue
                if not (name.endswith(".log") or name in ("syslog", "messages", "auth.log",
                                                          "kern.log", "dpkg.log", "btmp",
                                                          "wtmp", "faillog", "lastlog",
                                                          "alternatives.log", "cron", "daemon.log")):
                    if not name.startswith(("syslog", "messages", "auth")):
                        continue
                if full in seen:
                    continue
                seen.add(full)
                try:
                    st = os.stat(full)
                except OSError:
                    continue
                files.append({"path": full, "name": name, "size": st.st_size,
                              "mtime": st.st_mtime, "readable": os.access(full, os.R_OK)})
        except OSError:
            continue
    journal = shutil.which("journalctl") is not None
    return {"files": files, "journal": journal,
            "journal_reason": "" if journal else "journalctl is not installed",
            "note": "Files you cannot read without root are marked as such."}


def tail_file(cfg: Config, path: str, lines: int = 200, grep: str = "",
              max_bytes: int = 4 * 1024 * 1024) -> Dict[str, Any]:
    try:
        real = security.safe_path(path, cfg.allowed_roots + cfg.extra_log_dirs, must_exist=True)
    except security.PathError as exc:
        raise OpError(str(exc), 403)
    if not os.path.isfile(real):
        raise OpError("not a file", 400)
    if not os.access(real, os.R_OK):
        raise OpError("permission denied (try running the panel as a user in the adm/systemd-journal group)",
                      403)
    lines = max(1, min(5000, lines))
    size = os.path.getsize(real)
    start = max(0, size - max_bytes)
    with open(real, "rb") as fh:
        fh.seek(start)
        data = fh.read()
    text = data.decode("utf-8", "replace")
    all_lines = text.splitlines()
    if start > 0 and all_lines:
        all_lines = all_lines[1:]  # drop the partial first line
    if grep:
        needle = grep.lower()
        all_lines = [ln for ln in all_lines if needle in ln.lower()]
    truncated = len(all_lines) > lines
    return {"path": real, "lines": all_lines[-lines:], "truncated": truncated,
            "size": size, "grep": grep}


async def journal_lines(lines: int = 200, unit: Optional[str] = None, grep: str = "",
                        priority: str = "all") -> Dict[str, Any]:
    if not shutil.which("journalctl"):
        raise OpError("journalctl is not installed", 501)
    argv = ["journalctl", "-n", str(max(1, min(5000, lines))), "--no-pager",
            "--output=short-iso"]
    if unit:
        if not security.valid_service_name(unit):
            raise OpError("invalid unit", 400)
        argv += ["-u", unit]
    if priority in ("err", "warning", "info", "debug"):
        argv += ["-p", priority]
    if os.geteuid() != 0 and shutil.which("sudo"):
        argv = ["sudo", "-n"] + argv
    res = await run(argv, timeout=20)
    if not res["ok"] and "Permission denied" in (res["stderr"] or ""):
        raise OpError("journal access requires root or membership of systemd-journal", 403)
    out_lines = (res["stdout"] + res["stderr"]).splitlines()
    if grep:
        needle = grep.lower()
        out_lines = [ln for ln in out_lines if needle in ln.lower()]
    return {"lines": out_lines, "supported": True, "grep": grep, "unit": unit}


# ---------------------------------------------------------------------------
# Python execution
# ---------------------------------------------------------------------------
async def run_python(cfg: Config, code: str, filename: str = "script.py",
                     cwd: Optional[str] = None, args: Optional[List[str]] = None) -> Dict[str, Any]:
    if not code or len(code) > 512 * 1024:
        raise OpError("script is empty or too large", 400)
    if not re.match(r"^[A-Za-z0-9._-]{1,64}\.py$", filename or ""):
        filename = "script.py"
    workdir = cfg.data_dir
    if cwd:
        try:
            workdir = security.safe_path(cwd, cfg.allowed_roots, must_exist=True)
        except security.PathError as exc:
            raise OpError(str(exc), 403)
        if not os.path.isdir(workdir):
            raise OpError("working directory is not a directory", 400)
    python = shutil.which("python3") or shutil.which("python")
    if not python:
        raise OpError("python3 is not installed on this server", 501)
    tmpdir = tempfile.mkdtemp(prefix="prime-py-")
    script = os.path.join(tmpdir, filename)
    with open(script, "w", encoding="utf-8") as fh:
        fh.write(code)
    argv = [python, "-u", script] + [str(a) for a in (args or [])][:32]
    res = await run(argv, timeout=cfg.python_timeout, cwd=workdir)
    res["script_path"] = script
    res["temperature"] = "the script runs as the panel's own user, with the same privileges"
    # keep the script for reference but do not leak the tmp dir forever
    try:
        for name in os.listdir(tmpdir):
            if name != filename:
                shutil.rmtree(os.path.join(tmpdir, name), ignore_errors=True)
    except OSError:
        pass
    return res


# ---------------------------------------------------------------------------
# Network diagnostics
# ---------------------------------------------------------------------------
DIAG_TOOLS = {
    "ping": {"argv": ["ping", "-c", "4", "-W", "2", "{target}"], "args": ["target"],
             "label": "Ping (4 packets)"},
    "dns": {"argv": ["getent", "hosts", "{target}"], "args": ["target"], "label": "DNS lookup"},
    "trace": {"argv": ["traceroute", "-m", "16", "-w", "1", "{target}"], "args": ["target"],
              "label": "Traceroute"},
    "http": {"argv": ["curl", "-sS", "-I", "--max-time", "12", "{target}"], "args": ["target"],
             "label": "HTTP HEAD"},
    "ports": {"argv": ["ss", "-tulpn"], "args": [], "label": "Listening sockets"},
    "route": {"argv": ["ip", "route"], "args": [], "label": "Routing table"},
    "arp": {"argv": ["ip", "neigh"], "args": [], "label": "Neighbour table"},
}
HOST_RE = re.compile(r"^[A-Za-z0-9._:\-\[\]]{1,253}$")


async def diagnose(tool: str, target: str = "") -> Dict[str, Any]:
    spec = DIAG_TOOLS.get(tool)
    if not spec:
        raise OpError("unknown diagnostic tool", 400)
    argv = list(spec["argv"])
    if "target" in spec["args"]:
        t = (target or "").strip()
        if not t or not HOST_RE.match(t):
            raise OpError("invalid host or URL", 400)
        if tool == "http" and not t.startswith(("http://", "https://")):
            t = "http://" + t
        argv = [a.replace("{target}", t) for a in argv]
        if tool == "trace" and not shutil.which("traceroute"):
            argv[0] = "tracepath" if shutil.which("tracepath") else argv[0]
    if not shutil.which(argv[0]):
        raise OpError(f"{argv[0]} is not installed on this server "
                      f"(install it with your package manager)", 501)
    res = await run(argv, timeout=45)
    return {**res, "label": spec["label"], "tool": tool}


# ---------------------------------------------------------------------------
# SSH keys
# ---------------------------------------------------------------------------
def _authorized_keys_path(home: str) -> str:
    return os.path.join(home, ".ssh", "authorized_keys")


def list_ssh_keys(user: str) -> Dict[str, Any]:
    try:
        pw = pwd.getpwnam(user)
    except KeyError:
        raise OpError("unknown user", 404)
    path = _authorized_keys_path(pw.pw_dir)
    keys = []
    if os.path.exists(path):
        if not os.access(path, os.R_OK):
            raise OpError(f"permission denied reading {path}", 403)
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            for idx, line in enumerate(fh.read().splitlines()):
                stripped = line.strip()
                if not stripped or stripped.startswith("#"):
                    continue
                parts = stripped.split()
                keys.append({
                    "index": idx,
                    "type": parts[0] if parts else "",
                    "fingerprint_hint": (parts[1][:24] + "…") if len(parts) > 1 else "",
                    "comment": " ".join(parts[2:]) if len(parts) > 2 else "",
                    "full": stripped,
                })
    return {"user": pw.pw_name, "home": pw.pw_dir, "path": path,
            "exists": os.path.exists(path), "keys": keys,
            "writable": os.access(path, os.W_OK) if os.path.exists(path)
                        else os.access(pw.pw_dir, os.W_OK)}


def add_ssh_key(user: str, key: str, comment: str = "") -> Dict[str, Any]:
    try:
        pw = pwd.getpwnam(user)
    except KeyError:
        raise OpError("unknown user", 404)
    line = (key or "").strip()
    if not security.valid_ssh_key(line):
        raise OpError("that does not look like an OpenSSH public key", 400)
    if comment:
        parts = line.split()
        if len(parts) >= 3:
            line = " ".join(parts[:2] + [re.sub(r"\s+", "_", comment)])
        else:
            line = " ".join(parts[:2] + [re.sub(r"\s+", "_", comment)])
    ssh_dir = os.path.join(pw.pw_dir, ".ssh")
    path = _authorized_keys_path(pw.pw_dir)
    existing = ""
    if os.path.exists(path):
        if not os.access(path, os.R_OK):
            raise OpError(f"permission denied reading {path}", 403)
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            existing = fh.read()
    blob = line.split()[1] if len(line.split()) > 1 else line
    if blob and any(blob in ln for ln in existing.splitlines()):
        raise OpError("that key is already authorized", 409)
    try:
        os.makedirs(ssh_dir, mode=0o700, exist_ok=True)
        if os.geteuid() == 0:
            os.chown(ssh_dir, pw.pw_uid, pw.pw_gid)
        with open(path, "a", encoding="utf-8") as fh:
            if existing and not existing.endswith("\n"):
                fh.write("\n")
            fh.write(line + "\n")
        os.chmod(path, 0o600)
        if os.geteuid() == 0:
            os.chown(path, pw.pw_uid, pw.pw_gid)
    except PermissionError:
        raise OpError(f"permission denied writing {path} — the panel must run as {user} or root",
                      403)
    except OSError as exc:
        raise OpError(str(exc), 500)
    return list_ssh_keys(user)


def remove_ssh_key(user: str, index: int) -> Dict[str, Any]:
    try:
        pw = pwd.getpwnam(user)
    except KeyError:
        raise OpError("unknown user", 404)
    path = _authorized_keys_path(pw.pw_dir)
    if not os.path.exists(path):
        raise OpError("no authorized_keys file", 404)
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        lines = fh.read().splitlines()
    if index < 0 or index >= len(lines):
        raise OpError("key index out of range", 400)
    if not lines[index].strip() or lines[index].strip().startswith("#"):
        raise OpError("that line is not a key", 400)
    removed = lines.pop(index)
    try:
        with open(path, "w", encoding="utf-8") as fh:
            fh.write("\n".join(lines) + ("\n" if lines else ""))
    except PermissionError:
        raise OpError("permission denied", 403)
    return {**list_ssh_keys(user), "removed": removed[:60] + "…"}


async def generate_ssh_keypair(user: str, comment: str = "prime-terminal") -> Dict[str, Any]:
    if not shutil.which("ssh-keygen"):
        raise OpError("ssh-keygen is not installed", 501)
    try:
        pw = pwd.getpwnam(user)
    except KeyError:
        raise OpError("unknown user", 404)
    ssh_dir = os.path.join(pw.pw_dir, ".ssh")
    key_path = os.path.join(ssh_dir, "id_ed25519_prime")
    if os.path.exists(key_path):
        raise OpError("a key named id_ed25519_prime already exists", 409)
    try:
        os.makedirs(ssh_dir, mode=0o700, exist_ok=True)
    except PermissionError:
        raise OpError("permission denied creating ~/.ssh", 403)
    res = await run(["ssh-keygen", "-t", "ed25519", "-N", "", "-C",
                     re.sub(r"\s+", "_", comment or "prime-terminal"), "-f", key_path],
                    timeout=20)
    if not res["ok"]:
        raise OpError(res["stderr"] or "ssh-keygen failed", 500)
    try:
        os.chmod(key_path, 0o600)
        if os.geteuid() == 0:
            os.chown(key_path, pw.pw_uid, pw.pw_gid)
            os.chown(key_path + ".pub", pw.pw_uid, pw.pw_gid)
    except OSError:
        pass
    pub = ""
    try:
        with open(key_path + ".pub", "r", encoding="utf-8") as fh:
            pub = fh.read().strip()
    except OSError:
        pass
    return {"private_key_path": key_path, "public_key": pub, "output": res["stdout"]}


# ---------------------------------------------------------------------------
# Misc
# ---------------------------------------------------------------------------
def users_list() -> List[Dict[str, Any]]:
    out = []
    for pw in pwd.getpwall():
        if pw.pw_uid >= 1000 or pw.pw_uid == 0:
            out.append({"name": pw.pw_name, "uid": pw.pw_uid, "gid": pw.pw_gid,
                        "home": pw.pw_dir, "shell": pw.pw_shell})
    out.sort(key=lambda u: u["uid"])
    return out


def panel_status(cfg: Config, extra: Dict[str, Any]) -> Dict[str, Any]:
    up = time.time() - sysinfo.PROC_SAMPLER.boot_time if sysinfo.PROC_SAMPLER.boot_time else 0
    try:
        rss = int(open("/proc/self/statm").read().split()[1]) * sysinfo.PAGE_SIZE
    except (OSError, IndexError):
        rss = 0
    return {
        "name": "PRIME TERMINAL MANAGER",
        "version": extra.get("version", ""),
        "pid": os.getpid(),
        "user": pwd.getpwuid(os.geteuid()).pw_name,
        "data_dir": cfg.data_dir,
        "uptime_seconds": up,
        "rss": rss,
        "threads": len(os.listdir("/proc/self/task")),
        "read_only_files": cfg.read_only_files,
        "allowed_roots": cfg.allowed_roots,
        **{k: v for k, v in extra.items() if k != "version"},
    }
