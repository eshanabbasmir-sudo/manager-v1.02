"""Real PTY-backed terminal sessions.

Each session is a genuine fork/exec of the login shell attached to a
pseudo-terminal (``pty.openpty`` + ``setsid`` + ``TIOCSCTTY``). Output is read
from the master side straight into the WebSocket, and input/resize events are
written/ioctl'ed back — so ``top``, ``nano``, ``vim``, ``htop`` and friends
behave exactly as they do in a local terminal.
"""
from __future__ import annotations

import asyncio
import errno
import fcntl
import logging
import os
import pty
import pwd
import signal
import struct
import subprocess
import termios
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional

log = logging.getLogger("prime.terminal")


@dataclass
class Client:
    queue: "asyncio.Queue[bytes]"
    id: int = 0
    connected_at: float = field(default_factory=time.time)


class TermSession:
    def __init__(self, sid: str, proc: subprocess.Popen, fd: int, title: str,
                 shell: str, cwd: str, user: str, buffer_kb: int) -> None:
        self.id = sid
        self.proc = proc
        self.fd = fd
        self.title = title
        self.shell = shell
        self.cwd = cwd
        self.user = user
        self.created = time.time()
        self.last_active = time.time()
        self.exit_code: Optional[int] = None
        self.alive = True
        self.clients: Dict[int, Client] = {}
        self.cols = 80
        self.rows = 24
        self._buffer = bytearray()
        self._buffer_limit = max(16, buffer_kb) * 1024
        self._read_task: Optional[asyncio.Task] = None
        self._write_pending = bytearray()
        self._next_client_id = 1
        self.loop: Optional[asyncio.AbstractEventLoop] = None

    # -- buffering ------------------------------------------------------
    def _append(self, data: bytes) -> None:
        self._buffer.extend(data)
        if len(self._buffer) > self._buffer_limit:
            del self._buffer[: len(self._buffer) - self._buffer_limit]

    def snapshot_bytes(self) -> bytes:
        return bytes(self._buffer)

    def broadcast(self, data: bytes) -> None:
        self._append(data)
        self.last_active = time.time()
        for cid, client in list(self.clients.items()):
            try:
                client.queue.put_nowait(data)
            except asyncio.QueueFull:
                log.warning("terminal client %s too slow, dropping it", cid)
                self.clients.pop(cid, None)
                try:
                    client.queue.put_nowait(b"\r\n[prime] client dropped: too slow\r\n")
                except asyncio.QueueFull:
                    pass

    def info(self) -> dict:
        return {
            "id": self.id,
            "title": self.title,
            "shell": self.shell,
            "cwd": self.cwd,
            "user": self.user,
            "created": self.created,
            "last_active": self.last_active,
            "alive": self.alive and self.proc.poll() is None,
            "clients": len(self.clients),
            "cols": self.cols,
            "rows": self.rows,
            "pid": self.proc.pid,
            "exit_code": self.exit_code,
        }


class TerminalManager:
    def __init__(self, cfg) -> None:
        self.cfg = cfg
        self.sessions: Dict[str, TermSession] = {}
        self._counter = 0

    # -- lifecycle ------------------------------------------------------
    def _spawn(self, cols: int, rows: int, cwd: Optional[str], shell: Optional[str]) -> TermSession:
        shell_path = shell or self.cfg.shell_path
        if not os.path.exists(shell_path):
            raise RuntimeError(f"shell not found: {shell_path}")
        home = os.path.expanduser("~")
        workdir = cwd if (cwd and os.path.isdir(cwd)) else (home if os.path.isdir(home) else "/")
        master, slave = pty.openpty()
        env = {
            "PATH": os.environ.get("PATH", "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"),
            "TERM": "xterm-256color",
            "COLORTERM": "truecolor",
            "LANG": os.environ.get("LANG", "C.UTF-8"),
            "LC_ALL": os.environ.get("LC_ALL", os.environ.get("LANG", "C.UTF-8")),
            "HOME": home,
            "SHELL": shell_path,
            "USER": pwd.getpwuid(os.geteuid()).pw_name,
            "LOGNAME": pwd.getpwuid(os.geteuid()).pw_name,
            "PRIME_TERMINAL": "1",
            "TERM_PROGRAM": "PRIME-TERMINAL",
        }
        # initial window size
        fcntl.ioctl(master, termios.TIOCSWINSZ, struct.pack("HHHH", rows, cols, 0, 0))

        def _child_setup() -> None:  # runs in the child between fork and exec
            os.setsid()
            try:
                fcntl.ioctl(0, termios.TIOCSCTTY, 0)
            except OSError:
                pass
            os.chdir(workdir)

        try:
            proc = subprocess.Popen(
                [shell_path, "-l"] if os.path.basename(shell_path) in ("bash", "zsh") else [shell_path],
                stdin=slave, stdout=slave, stderr=slave, env=env, close_fds=True,
                preexec_fn=_child_setup, start_new_session=False,
            )
        except Exception:
            os.close(master)
            os.close(slave)
            raise
        finally:
            try:
                os.close(slave)
            except OSError:
                pass

        os.set_blocking(master, False)
        self._counter += 1
        sid = f"t{int(time.time()*1000):x}{self._counter:02x}"
        sess = TermSession(sid, proc, master, f"Shell {self._counter}", shell_path, workdir,
                           pwd.getpwuid(os.geteuid()).pw_name, self.cfg.term_buffer_kb)
        sess.cols, sess.rows = cols, rows
        self.sessions[sid] = sess
        log.info("terminal session %s started (pid %s, shell %s)", sid, proc.pid, shell_path)
        return sess

    async def create(self, cols: int = 80, rows: int = 24, cwd: Optional[str] = None,
                     shell: Optional[str] = None) -> TermSession:
        alive = [s for s in self.sessions.values() if s.alive and s.proc.poll() is None]
        if len(alive) >= self.cfg.term_max_sessions:
            oldest = min((s for s in alive if not s.clients), key=lambda s: s.last_active,
                         default=None)
            if oldest is None:
                raise RuntimeError(
                    f"maximum of {self.cfg.term_max_sessions} terminal sessions reached; "
                    "close one first")
            await self.close(oldest.id)
        sess = self._spawn(cols, rows, cwd, shell)
        sess.loop = asyncio.get_running_loop()
        self._attach_reader(sess)
        return sess

    def _attach_reader(self, sess: TermSession) -> None:
        loop = asyncio.get_running_loop()
        sess.loop = loop

        def on_readable() -> None:
            try:
                data = os.read(sess.fd, 65536)
            except BlockingIOError:
                return
            except OSError as exc:
                if exc.errno in (errno.EIO, errno.EBADF):
                    self._finish(sess)
                    return
                log.warning("terminal read error: %s", exc)
                self._finish(sess)
                return
            if not data:
                self._finish(sess)
                return
            sess.broadcast(data)

        def on_writable() -> None:
            if not sess._write_pending:
                loop.remove_writer(sess.fd)
                return
            try:
                n = os.write(sess.fd, bytes(sess._write_pending[:65536]))
                del sess._write_pending[:n]
            except BlockingIOError:
                return
            except OSError:
                self._finish(sess)
                return
            if not sess._write_pending:
                loop.remove_writer(sess.fd)

        sess._on_readable = on_readable  # type: ignore[attr-defined]
        sess._on_writable = on_writable  # type: ignore[attr-defined]
        loop.add_reader(sess.fd, on_readable)

    def _finish(self, sess: TermSession) -> None:
        if not sess.alive:
            return
        sess.alive = False
        try:
            code = sess.proc.poll()
            if code is None:
                try:
                    code = sess.proc.wait(timeout=1)
                except subprocess.TimeoutExpired:
                    code = -1
        except Exception:
            code = -1
        sess.exit_code = code
        loop = sess.loop
        if loop and loop.is_running():
            try:
                loop.remove_reader(sess.fd)
            except Exception:
                pass
            try:
                loop.remove_writer(sess.fd)
            except Exception:
                pass
        try:
            os.close(sess.fd)
        except OSError:
            pass
        msg = f"\r\n\x1b[38;5;244m[prime] session ended (exit code {code})\x1b[0m\r\n"
        sess.broadcast(msg.encode())
        for client in list(sess.clients.values()):
            try:
                client.queue.put_nowait(b"")
            except asyncio.QueueFull:
                pass
        log.info("terminal session %s ended with code %s", sess.id, code)

    async def close(self, sid: str, force: bool = False) -> bool:
        sess = self.sessions.pop(sid, None)
        if sess is None:
            return False
        try:
            if sess.proc.poll() is None:
                try:
                    os.killpg(os.getpgid(sess.proc.pid), signal.SIGHUP)
                except OSError:
                    pass
                try:
                    sess.proc.terminate()
                except OSError:
                    pass
                try:
                    await asyncio.get_running_loop().run_in_executor(None, lambda: sess.proc.wait(2))
                except subprocess.TimeoutExpired:
                    if force:
                        try:
                            os.killpg(os.getpgid(sess.proc.pid), signal.SIGKILL)
                        except OSError:
                            pass
        finally:
            self._finish(sess)
        log.info("terminal session %s closed", sid)
        return True

    async def close_all(self) -> None:
        for sid in list(self.sessions):
            await self.close(sid, force=True)

    async def reap_idle(self) -> None:
        """Close sessions that nobody has been attached to for a long time."""
        now = time.time()
        for sid, sess in list(self.sessions.items()):
            if sess.proc.poll() is not None:
                self._finish(sess)
                self.sessions.pop(sid, None)
                continue
            if not sess.clients and now - sess.last_active > self.cfg.term_linger:
                log.info("reaping idle terminal session %s", sid)
                await self.close(sid)

    def get(self, sid: str) -> Optional[TermSession]:
        return self.sessions.get(sid)

    def list(self) -> List[dict]:
        out = []
        for sid, sess in self.sessions.items():
            if sess.proc.poll() is not None:
                self._finish(sess)
            out.append(sess.info())
        out.sort(key=lambda x: x["created"])
        return out

    # -- io -------------------------------------------------------------
    def write(self, sess: TermSession, data: bytes) -> None:
        if not data or not sess.alive:
            return
        sess.last_active = time.time()
        sess._write_pending.extend(data)
        loop = sess.loop or asyncio.get_event_loop()
        try:
            n = os.write(sess.fd, bytes(sess._write_pending[:65536]))
            del sess._write_pending[:n]
        except BlockingIOError:
            pass
        except OSError:
            self._finish(sess)
            return
        if sess._write_pending:
            try:
                loop.add_writer(sess.fd, sess._on_writable)  # type: ignore[attr-defined]
            except Exception:
                pass

    def resize(self, sess: TermSession, cols: int, rows: int) -> None:
        cols = max(2, min(512, int(cols)))
        rows = max(2, min(256, int(rows)))
        sess.cols, sess.rows = cols, rows
        try:
            fcntl.ioctl(sess.fd, termios.TIOCSWINSZ, struct.pack("HHHH", rows, cols, 0, 0))
        except OSError as exc:
            log.debug("resize failed: %s", exc)
