"""System information endpoints — all values come from /proc, /sys or statvfs."""
from __future__ import annotations

from fastapi import APIRouter, HTTPException, Query, Request

from .. import ops, sysinfo
from ..auth import AuthError
from ..deps import client_ip, get_rt, get_session, require_csrf

router = APIRouter(prefix="/api/system", tags=["system"])


@router.get("/snapshot")
async def snapshot(request: Request):
    get_session(request)
    return sysinfo.snapshot()


@router.get("/overview")
async def overview(request: Request):
    rt = get_rt(request)
    get_session(request)
    return {
        "os": sysinfo.os_info(),
        "cpu": sysinfo.cpu_info(),
        "memory": sysinfo.memory_info(),
        "disk": sysinfo.disk_info(),
        "network": sysinfo.network_info(),
        "capabilities": sysinfo.capabilities(),
        "panel": ops.panel_status(rt.cfg, {"version": rt.version,
                                           "sessions": len(rt.terms.sessions),
                                           "started": rt.started}),
        "thermal": sysinfo.thermal_info(),
    }


@router.get("/cpu")
async def cpu(request: Request):
    get_session(request)
    return sysinfo.cpu_info()


@router.get("/memory")
async def memory(request: Request):
    get_session(request)
    return sysinfo.memory_info()


@router.get("/disk")
async def disk(request: Request):
    get_session(request)
    return sysinfo.disk_info()


@router.get("/network")
async def network(request: Request):
    get_session(request)
    return sysinfo.network_info()


@router.get("/processes")
async def processes(request: Request, limit: int = Query(200, ge=1, le=2000),
                    sort: str = Query("cpu", pattern="^(cpu|mem|pid|name)$")):
    get_session(request)
    return sysinfo.list_processes(limit=limit, sort=sort)


@router.get("/process/{pid}")
async def process_detail(pid: int, request: Request):
    get_session(request)
    detail = sysinfo.process_detail(pid)
    if detail is None:
        raise HTTPException(404, "no such process")
    return detail


@router.post("/process/{pid}/signal")
async def process_signal(pid: int, request: Request, signal: str = Query("TERM")):
    rt = get_rt(request)
    session = get_session(request)
    require_csrf(request, session)
    if pid <= 1:
        raise HTTPException(400, "refusing to signal PID 1")
    ok, message = sysinfo.kill_process(pid, signal)
    rt.auth.audit("process.signal", f"{signal} {pid}: {message}", ok, session.username,
                  client_ip(request))
    if not ok:
        raise HTTPException(403 if "permission" in message else 400, message)
    return {"ok": True, "message": message}


@router.get("/ports")
async def ports(request: Request):
    get_session(request)
    return sysinfo.listening_ports()


@router.get("/capabilities")
async def capabilities(request: Request):
    get_session(request)
    return sysinfo.capabilities()


@router.get("/panel")
async def panel(request: Request):
    rt = get_rt(request)
    get_session(request)
    return ops.panel_status(rt.cfg, {"version": rt.version,
                                     "sessions": len(rt.terms.sessions),
                                     "started": rt.started})


@router.get("/users")
async def users(request: Request):
    get_session(request)
    import os
    import pwd
    return {"users": ops.users_list(),
            "whoami": pwd.getpwuid(os.geteuid()).pw_name,
            "root": os.geteuid() == 0}
