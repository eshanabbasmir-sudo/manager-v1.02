"""Toolkit endpoints (PRIME TERMINAL MANAGER v1.0.2)."""
from __future__ import annotations

from typing import Dict, List

from fastapi import APIRouter, HTTPException, Query, Request
from fastapi.responses import Response
from pydantic import BaseModel, Field

from .. import features
from ..deps import client_ip, get_rt, get_session, require_csrf

router = APIRouter(prefix="/api/toolkit", tags=["toolkit"])


class SnippetIn(BaseModel):
    title: str = Field(min_length=1, max_length=80)
    command: str = Field(min_length=1, max_length=4000)
    notes: str = Field(default="", max_length=300)


class ThresholdsIn(BaseModel):
    cpu: float = 85.0
    memory: float = 90.0
    disk: float = 90.0
    load_per_core: float = 1.5


class NotesIn(BaseModel):
    text: str = Field(default="", max_length=200 * 1024)


class CertIn(BaseModel):
    host: str = Field(min_length=1, max_length=253)
    port: int = Field(default=443, ge=1, le=65535)


def _store(request: Request) -> features.ToolkitStore:
    return features.ToolkitStore(get_rt(request).cfg)


def _wrap(exc: features.FeatureError) -> HTTPException:
    return HTTPException(exc.code, exc.message)


# 1. snippets ---------------------------------------------------------------
@router.get("/snippets")
async def list_snippets(request: Request):
    get_session(request)
    return features.list_snippets(_store(request))


@router.post("/snippets")
async def create_snippet(payload: SnippetIn, request: Request):
    rt = get_rt(request)
    session = get_session(request)
    require_csrf(request, session)
    try:
        item = features.save_snippet(_store(request), payload.title, payload.command, payload.notes)
    except features.FeatureError as exc:
        raise _wrap(exc)
    rt.auth.audit("toolkit.snippet", f"saved '{item['title']}'", True, session.username,
                  client_ip(request))
    return item


@router.delete("/snippets/{snippet_id}")
async def remove_snippet(snippet_id: str, request: Request):
    rt = get_rt(request)
    session = get_session(request)
    require_csrf(request, session)
    if not features.delete_snippet(_store(request), snippet_id):
        raise HTTPException(404, "no such snippet")
    rt.auth.audit("toolkit.snippet", f"deleted {snippet_id}", True, session.username,
                  client_ip(request))
    return {"ok": True}


@router.post("/snippets/{snippet_id}/run")
async def run_snippet(snippet_id: str, request: Request):
    rt = get_rt(request)
    session = get_session(request)
    require_csrf(request, session)
    try:
        result = await features.run_snippet(_store(request), rt.jobs, snippet_id)
    except features.FeatureError as exc:
        raise _wrap(exc)
    rt.auth.audit("toolkit.snippet.run", snippet_id, True, session.username, client_ip(request))
    return result


# 2. alerts -----------------------------------------------------------------
@router.get("/alerts")
async def alerts(request: Request):
    get_session(request)
    return features.evaluate_alerts(_store(request))


@router.put("/alerts/thresholds")
async def set_thresholds(payload: ThresholdsIn, request: Request):
    rt = get_rt(request)
    session = get_session(request)
    require_csrf(request, session)
    try:
        values = features.set_thresholds(_store(request), payload.dict())
    except features.FeatureError as exc:
        raise _wrap(exc)
    rt.auth.audit("toolkit.thresholds", str(values), True, session.username, client_ip(request))
    return values


# 3. report -----------------------------------------------------------------
@router.get("/report.md")
async def report(request: Request):
    rt = get_rt(request)
    get_session(request)
    body = features.build_report(rt.cfg, rt.version)
    return Response(body, media_type="text/markdown; charset=utf-8",
                    headers={"Content-Disposition": 'attachment; filename="prime-report.md"',
                             "Cache-Control": "no-store"})


# 4. port finder ------------------------------------------------------------
@router.get("/ports/{port}")
async def port_lookup(port: int, request: Request):
    get_session(request)
    try:
        return features.find_port(port)
    except features.FeatureError as exc:
        raise _wrap(exc)


# 5. crontab ----------------------------------------------------------------
@router.get("/cron")
async def cron(request: Request, user: str = Query("", max_length=40)):
    rt = get_rt(request)
    get_session(request)
    import os
    try:
        return await features.read_crontab(user, is_root=os.geteuid() == 0)
    except features.FeatureError as exc:
        raise _wrap(exc)


# 6. certificate expiry -----------------------------------------------------
@router.post("/certificate")
async def certificate(payload: CertIn, request: Request):
    get_session(request)
    try:
        return await features.check_certificate(payload.host, payload.port)
    except features.FeatureError as exc:
        raise _wrap(exc)


# 7. largest folders --------------------------------------------------------
@router.get("/disk-usage")
async def disk_usage(request: Request, path: str = Query("/", max_length=1024)):
    rt = get_rt(request)
    get_session(request)
    try:
        return await features.largest_dirs(rt.cfg, path)
    except features.FeatureError as exc:
        raise _wrap(exc)


# 8. recent logins ----------------------------------------------------------
@router.get("/logins")
async def logins(request: Request):
    get_session(request)
    return await features.recent_logins()


# 9. time sync -------------------------------------------------------------
@router.get("/time")
async def time_status(request: Request):
    get_session(request)
    return await features.time_sync()


# 10. runbook notes ---------------------------------------------------------
@router.get("/notes")
async def get_notes(request: Request):
    get_session(request)
    return features.get_notes(_store(request))


@router.put("/notes")
async def set_notes(payload: NotesIn, request: Request):
    rt = get_rt(request)
    session = get_session(request)
    require_csrf(request, session)
    try:
        result = features.set_notes(_store(request), payload.text)
    except features.FeatureError as exc:
        raise _wrap(exc)
    rt.auth.audit("toolkit.notes", f"{len(payload.text)} chars", True, session.username,
                  client_ip(request))
    return result
