/** systemd / OpenRC service management with honest capability reporting. */
import { api } from "../api.js";
import { icon } from "../icons.js";
import * as ui from "../ui.js";
import { esc, timestamp } from "../ui.js";

const state = { data: null, filter: "", showAll: true, jobTimer: null };

function stateBadge(item) {
  const active = (item.active || "").toLowerCase();
  if (active === "active" || active === "running" || active === "started") return "ok";
  if (active === "failed") return "danger";
  if (active === "activating" || active === "reloading") return "warn";
  return "";
}

function rows() {
  const items = (state.data?.items || []).filter((i) => {
    const needle = state.filter.toLowerCase();
    if (!needle) return true;
    return i.name.toLowerCase().includes(needle) || (i.description || "").toLowerCase().includes(needle);
  });
  if (!items.length) {
    return `<tr><td colspan="4">${ui.emptyState(
      state.data?.backend?.kind === "none" ? "No service manager in this environment" : "No matching units",
      "layers")}</td></tr>`;
  }
  return items
    .map(
      (s) => `<tr>
      <td><span class="ellipsis mono" style="max-width:240px">${esc(s.name)}</span>
        <div class="faint ellipsis" style="font-size:11px;max-width:240px">${esc(s.description || "")}</div></td>
      <td><span class="badge ${stateBadge(s)}"><span class="dot"></span>${esc(s.active || "?")}</span>
        <span class="faint" style="font-size:11px">${esc(s.sub || "")}</span></td>
      <td class="faint mono">${esc(s.enabled || "—")}</td>
      <td class="actions">
        ${s.active === "active"
          ? `<button class="icon-btn" data-action="restart" data-name="${esc(s.name)}" title="Restart">${icon("restart")}</button>
             <button class="icon-btn" data-action="stop" data-name="${esc(s.name)}" title="Stop" style="color:var(--danger)">${icon("stop")}</button>`
          : `<button class="icon-btn" data-action="start" data-name="${esc(s.name)}" title="Start" style="color:var(--ok)">${icon("play")}</button>`}
        <button class="icon-btn" data-logs="${esc(s.name)}" title="Logs">${icon("scroll")}</button>
      </td>
    </tr>`,
    )
    .join("");
}

function shell() {
  const backend = state.data?.backend;
  return `<div class="view-enter">
    ${backend && backend.kind === "none"
      ? `<div class="notice danger">${icon("alert")}<div><b>No supported service manager.</b>
          ${esc(backend.note || "")}</div></div>`
      : ""}
    ${backend && backend.kind !== "none" && !state.data.can_control
      ? `<div class="notice">${icon("lock")}<div>Service actions need root. The panel runs as an
          unprivileged user and <span class="mono">sudo -n</span> may be unavailable.</div></div>`
      : ""}
    <div class="card" style="margin-top:${backend && backend.kind === "none" ? 16 : 0}px">
      <div class="card-head">
        <div class="card-title-icon">${icon("layers")}</div>
        <div><h3>Services</h3>
          <div class="sub">${esc(backend?.kind || "—")} · ${state.data?.items?.length || 0} units</div></div>
        <div class="spacer"></div>
        <button class="btn btn-sm" id="svc-refresh">${icon("refresh")}Refresh</button>
      </div>
      <div class="toolbar">
        <div class="search">${icon("search")}
          <input class="input" id="svc-filter" placeholder="Filter services…" value="${esc(state.filter)}">
        </div>
      </div>
      <div class="table-wrap"><table class="tbl">
        <thead><tr><th>Unit</th><th>Status</th><th>Enabled</th><th class="no-sort"></th></tr></thead>
        <tbody id="svc-body">${rows()}</tbody>
      </table></div>
    </div>
    <div id="svc-job" style="margin-top:16px"></div>
  </div>`;
}

async function load(container) {
  try {
    state.data = await api.get("/api/services");
  } catch (err) {
    container.innerHTML = `<div class="card">${ui.emptyState(ui.errorText(err), "alert")}</div>`;
    return;
  }
  container.innerHTML = shell();
}

async function runAction(name, action, container) {
  const jobHost = document.getElementById("svc-job");
  try {
    const { job } = await api.post("/api/services/action", { name, action });
    ui.notifyInfo("Service command running", `${action} ${name}`);
    if (jobHost) {
      jobHost.innerHTML = `<div class="card">
        <div class="card-head"><div class="card-title-icon">${icon("zap")}</div>
        <div><h3>${esc(action)} ${esc(name)}</h3><div class="sub mono">${esc(job.command)}</div></div></div>
        <pre class="code-out" id="job-out">running…</pre></div>`;
    }
    pollJob(job.id, container);
  } catch (err) {
    ui.showError(err, "Service action failed");
  }
}

function pollJob(jobId, container) {
  clearInterval(state.jobTimer);
  state.jobTimer = setInterval(async () => {
    try {
      const job = await api.get(`/api/jobs/${jobId}`);
      const out = document.getElementById("job-out");
      if (out) {
        out.textContent = `${job.output || ""}${job.error ? `\n${job.error}` : ""}` ||
          (job.running ? "running…" : "(no output)");
        out.scrollTop = out.scrollHeight;
      }
      if (!job.running) {
        clearInterval(state.jobTimer);
        state.jobTimer = null;
        if (job.exit_code === 0) ui.notifyOk("Done", `${job.label} succeeded`);
        else ui.notifyErr("Command failed", `exit code ${job.exit_code}`);
        setTimeout(() => load(container), 900);
      }
    } catch (err) {
      clearInterval(state.jobTimer);
      state.jobTimer = null;
    }
  }, 900);
}

async function showLogs(name) {
  const s = ui.sheet({
    title: `Logs · ${name}`,
    subtitle: "journalctl",
    content: `<div class="code-out" id="svc-log-out">loading…</div>`,
    wide: true,
    tall: true,
    actions: [
      { label: "Refresh", icon: "refresh", close: false, onClick: async () => {
        const out = document.getElementById("svc-log-out");
        out.textContent = "loading…";
        try {
          const res = await api.get("/api/services/logs", { name, lines: 300 });
          out.textContent = res.result.stdout || res.result.stderr || "(no log lines)";
        } catch (err) {
          out.textContent = ui.errorText(err);
        }
        return false;
      } },
      { label: "Close", kind: "ghost" },
    ],
  });
  try {
    const res = await api.get("/api/services/logs", { name, lines: 300 });
    const out = document.getElementById("svc-log-out");
    if (out) out.textContent = res.result.stdout || res.result.stderr || "(no log lines)";
  } catch (err) {
    const out = document.getElementById("svc-log-out");
    if (out) out.textContent = ui.errorText(err);
  }
  return s;
}

export default {
  title: "Services",
  crumb: "unit status and control",
  async mount(container, ctx) {
    container.innerHTML = ui.skeletonRows(2, 120);
    await load(container);
    container.addEventListener("click", (event) => {
      if (event.target.closest("#svc-refresh")) {
        load(container);
        return;
      }
      const actionBtn = event.target.closest("[data-action]");
      if (actionBtn) {
        runAction(actionBtn.dataset.name, actionBtn.dataset.action, container);
        return;
      }
      const logsBtn = event.target.closest("[data-logs]");
      if (logsBtn) showLogs(logsBtn.dataset.logs);
    });
    container.addEventListener("input", (event) => {
      if (event.target.id === "svc-filter") {
        state.filter = event.target.value;
        const body = document.getElementById("svc-body");
        if (body) body.innerHTML = rows();
      }
    });
  },
  unmount() {
    if (state.jobTimer) clearInterval(state.jobTimer);
    state.jobTimer = null;
  },
};
