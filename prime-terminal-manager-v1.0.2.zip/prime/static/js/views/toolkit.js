/** PRIME TERMINAL MANAGER — Toolkit: ten practical server tools in one place. */
import { api, downloadFile } from "../api.js";
import { icon } from "../icons.js";
import * as ui from "../ui.js";
import { esc, bytes, timestamp } from "../ui.js";

const PANELS = [
  { id: "snippets", label: "Snippets", icon: "terminalSquare" },
  { id: "alerts", label: "Health alerts", icon: "alert" },
  { id: "report", label: "Report", icon: "file" },
  { id: "ports", label: "Port finder", icon: "network" },
  { id: "cron", label: "Crontab", icon: "clock" },
  { id: "cert", label: "SSL expiry", icon: "shield" },
  { id: "disk", label: "Disk hogs", icon: "hardDrive" },
  { id: "logins", label: "Logins", icon: "users" },
  { id: "time", label: "Time sync", icon: "history" },
  { id: "notes", label: "Runbook", icon: "edit" },
];

const state = { panel: "snippets", cache: {}, container: null, pollTimer: null };

function shell() {
  return `<div class="view-enter tk">
    <div class="tk-tabs" role="tablist" id="tk-tabs">
      ${PANELS.map((p) => `<button class="tk-tab ${p.id === state.panel ? "active" : ""}" role="tab"
        data-panel="${p.id}" aria-selected="${p.id === state.panel}">${icon(p.icon)}<span>${esc(p.label)}</span></button>`).join("")}
    </div>
    <div id="tk-body"></div>
  </div>`;
}

function card(title, sub, body, iconName = "wrench") {
  return `<div class="card">
    <div class="card-head"><div class="card-title-icon">${icon(iconName)}</div>
      <div><h3>${esc(title)}</h3><div class="sub">${esc(sub)}</div></div></div>${body}</div>`;
}

function body() {
  return document.getElementById("tk-body");
}

/* ------------------------------------------------------- 1. snippets */
async function renderSnippets() {
  const data = await api.get("/api/toolkit/snippets");
  const items = data.items || [];
  return card("Command snippets", "save commands you repeat; run them as a background job",
    `<div class="field"><label>Title</label><input class="input" id="sn-title" maxlength="80" placeholder="Restart web stack"></div>
     <div class="field"><label>Command (runs with bash -c)</label>
       <textarea class="textarea mono" id="sn-cmd" rows="3" maxlength="4000" placeholder="systemctl restart nginx && echo done"></textarea></div>
     <div class="field"><label>Notes (optional)</label><input class="input" id="sn-notes" maxlength="300"></div>
     <button class="btn btn-primary" data-act="sn-add">${icon("plus")}Save snippet</button>
     <div class="list" style="margin-top:14px">${items.length ? items.map((s) => `
       <div class="list-row">
         <div class="grow" style="min-width:0"><div style="font-weight:600">${esc(s.title)}</div>
           <div class="faint mono truncate" style="font-size:12px">${esc(s.command)}</div>
           ${s.notes ? `<div class="faint" style="font-size:12px">${esc(s.notes)}</div>` : ""}</div>
         <button class="icon-btn" data-act="sn-run" data-id="${s.id}" aria-label="Run">${icon("play")}</button>
         <button class="icon-btn" data-act="sn-del" data-id="${s.id}" aria-label="Delete">${icon("trash")}</button>
       </div>`).join("") : ui.emptyState("No snippets yet.", "terminalSquare")}</div>
     <pre class="code-out" id="sn-out" style="display:none;margin-top:12px;max-height:40vh"></pre>`,
    "terminalSquare");
}

async function addSnippet() {
  const title = document.getElementById("sn-title").value;
  const command = document.getElementById("sn-cmd").value;
  const notes = document.getElementById("sn-notes").value;
  await api.post("/api/toolkit/snippets", { title, command, notes });
  ui.notifyOk("Saved", "Snippet saved");
  await show("snippets", true);
}

async function runSnippet(id) {
  const started = await api.post(`/api/toolkit/snippets/${id}/run`, {});
  const out = document.getElementById("sn-out");
  out.style.display = "";
  out.textContent = `running ${started.label}…`;
  clearInterval(state.pollTimer);
  state.pollTimer = setInterval(async () => {
    try {
      const job = await api.get(`/api/jobs/${started.job_id}`);
      out.textContent = job.output || "(no output yet)";
      if (!job.running) {
        clearInterval(state.pollTimer);
        out.textContent += `\n\n[exit ${job.exit_code}]`;
      }
    } catch (err) {
      clearInterval(state.pollTimer);
      out.textContent = ui.errorText(err);
    }
  }, 1000);
}

/* ------------------------------------------------------- 2. alerts */
function alertBar(value, limit) {
  const pctFill = Math.min(100, (value / Math.max(limit, 0.01)) * 100);
  const level = value >= limit ? "danger" : value >= limit * 0.85 ? "warn" : "ok";
  return `<div class="progress ${level}"><i style="width:${pctFill.toFixed(0)}%"></i></div>`;
}

async function renderAlerts() {
  const data = await api.get("/api/toolkit/alerts");
  const t = data.thresholds;
  const rows = [
    ["cpu", "CPU usage", "%"], ["memory", "Memory used", "%"],
    ["disk", "Root disk used", "%"], ["load_per_core", "Load per core", ""],
  ];
  const banner = data.ok
    ? `<div class="notice">${icon("check")}<div>All checks are within their limits.</div></div>`
    : `<div class="notice">${icon("alert")}<div>${data.alerts.length} alert(s): ${data.alerts
        .map((a) => `${esc(a.label)} (${esc(a.severity)})`).join(", ")}</div></div>`;
  return card("Health alerts", "thresholds you set; checked against live kernel values",
    `${banner}
     <div class="grid cols-2" style="margin-top:14px">${rows.map(([key, label, unit]) => `
       <div class="field"><label>${esc(label)} limit${unit ? ` (${unit})` : ""}</label>
         <input class="input mono" type="number" step="0.1" id="th-${key}" value="${t[key]}"></div>`).join("")}
     </div>
     <div class="row" style="gap:8px;margin-top:6px">
       <button class="btn btn-primary" data-act="th-save">${icon("save")}Save thresholds</button>
       <button class="btn btn-ghost" data-act="th-refresh">${icon("refresh")}Re-check now</button></div>
     <div class="list" style="margin-top:14px">${rows.map(([key, label, unit]) => {
       const a = data.alerts.find((x) => x.key === key);
       const current = a ? a.value : null;
       return `<div class="list-row"><div class="grow"><div>${esc(label)}</div>
         <div class="faint" style="font-size:12px">limit ${t[key]}${unit}</div></div>
         <div class="mono">${current === null ? "ok" : `${current}${unit}`}</div></div>`;
     }).join("")}</div>`,
    "alert");
}

async function saveThresholds() {
  const payload = {};
  ["cpu", "memory", "disk", "load_per_core"].forEach((k) => {
    payload[k] = Number(document.getElementById(`th-${k}`).value);
  });
  await api.put("/api/toolkit/alerts/thresholds", payload);
  ui.notifyOk("Saved", "Thresholds updated");
  await show("alerts", true);
}

/* ------------------------------------------------------- 3. report */
function renderReport() {
  return card("System report", "a Markdown snapshot: host, CPU, memory, disk, alerts and open ports",
    `<p class="faint" style="margin:0 0 14px">Download a report you can paste into a ticket or keep as a record.</p>
     <button class="btn btn-primary" data-act="report-dl">${icon("download")}Download prime-report.md</button>`,
    "file");
}

/* ------------------------------------------------------- 4. ports */
async function renderPorts() {
  return card("Port finder", "which process is listening on a port",
    `<div class="row" style="gap:8px;flex-wrap:wrap"><input class="input mono" id="pf-port" type="number" min="1" max="65535"
       placeholder="8080" style="max-width:160px"><button class="btn btn-primary" data-act="pf-go">${icon("search")}Find</button></div>
     <div id="pf-out" style="margin-top:14px"></div>`,
    "network");
}

async function findPort() {
  const port = Number(document.getElementById("pf-port").value);
  const out = document.getElementById("pf-out");
  const data = await api.get(`/api/toolkit/ports/${port}`);
  out.innerHTML = data.in_use
    ? `<div class="list">${data.items.map((r) => `<div class="list-row"><div class="grow">
        <div class="mono">${esc(r.protocol)} ${esc(r.address)}:${r.port}</div>
        <div class="faint" style="font-size:12px">${esc(r.process || "owner hidden (run as root to see)")} ${r.pid ? `· pid ${r.pid}` : ""}</div>
        </div><span class="badge ok">${esc(r.state)}</span></div>`).join("")}</div>`
    : ui.emptyState(`Nothing is listening on port ${port}.`, "info");
}

/* ------------------------------------------------------- 5. crontab */
function renderCron() {
  return card("Crontab viewer", "read-only view of scheduled jobs",
    `<div class="row" style="gap:8px;flex-wrap:wrap"><input class="input mono" id="cr-user" placeholder="blank = current user (root can enter a name)" style="max-width:320px">
       <button class="btn btn-primary" data-act="cr-go">${icon("search")}Show</button></div>
     <pre class="code-out" id="cr-out" style="margin-top:14px;max-height:45vh">press Show</pre>`,
    "clock");
}

async function showCron() {
  const user = document.getElementById("cr-user").value.trim();
  const data = await api.get("/api/toolkit/cron", { user });
  document.getElementById("cr-out").textContent = data.content || data.note || "(empty crontab)";
}

/* ------------------------------------------------------- 6. SSL */
function renderCert() {
  return card("SSL certificate expiry", "connect over TLS and read the certificate's expiry date",
    `<div class="row" style="gap:8px;flex-wrap:wrap"><input class="input mono" id="ce-host" placeholder="example.com" style="flex:1;min-width:180px">
       <input class="input mono" id="ce-port" type="number" value="443" style="max-width:110px">
       <button class="btn btn-primary" data-act="ce-go">${icon("shield")}Check</button></div>
     <div id="ce-out" style="margin-top:14px"></div>`,
    "shield");
}

async function checkCert() {
  const host = document.getElementById("ce-host").value.trim();
  const port = Number(document.getElementById("ce-port").value || 443);
  const out = document.getElementById("ce-out");
  out.innerHTML = `<div class="faint">checking…</div>`;
  const r = await api.post("/api/toolkit/certificate", { host, port });
  if (!r.ok) {
    out.innerHTML = `<div class="notice">${icon("alert")}<div>${esc(r.error)}</div></div>`;
    return;
  }
  const level = { ok: "ok", warning: "warn", critical: "danger", expired: "danger" }[r.status];
  out.innerHTML = `<div class="list">
    <div class="list-row"><div class="grow">Expires</div><span class="badge ${level}">${r.days_left} days · ${esc(r.expires)}</span></div>
    <div class="list-row"><div class="grow">Subject</div><div class="mono">${esc(r.subject || "—")}</div></div>
    <div class="list-row"><div class="grow">Issuer</div><div>${esc(r.issuer || "—")}</div></div>
    <div class="list-row"><div class="grow">Protocol</div><div class="mono">${esc(r.tls)}</div></div></div>`;
}

/* ------------------------------------------------------- 7. disk hogs */
function renderDisk() {
  return card("Largest folders", "find what is filling a disk (one level deep)",
    `<div class="row" style="gap:8px;flex-wrap:wrap"><input class="input mono" id="dk-path" value="/" style="flex:1;min-width:180px">
       <button class="btn btn-primary" data-act="dk-go">${icon("search")}Scan</button></div>
     <div id="dk-out" style="margin-top:14px"></div>`,
    "hardDrive");
}

async function scanDisk() {
  const path = document.getElementById("dk-path").value.trim() || "/";
  const out = document.getElementById("dk-out");
  out.innerHTML = `<div class="faint">scanning ${esc(path)}…</div>`;
  const data = await api.get("/api/toolkit/disk-usage", { path });
  const max = Math.max(1, ...data.items.map((i) => i.bytes));
  out.innerHTML = data.items.length
    ? `<div class="list">${data.items.map((i) => `<div class="list-row" style="flex-direction:column;align-items:stretch">
        <div class="row between"><span class="mono truncate">${esc(i.path)}</span><span class="mono">${bytes(i.bytes)}</span></div>
        <div class="progress"><i style="width:${((i.bytes / max) * 100).toFixed(1)}%"></i></div></div>`).join("")}</div>`
    : `<div class="notice">${icon("alert")}<div>${esc(data.note || "Nothing found.")}</div></div>`;
}

/* ------------------------------------------------------- 8. logins */
async function renderLogins() {
  const data = await api.get("/api/toolkit/logins");
  const items = data.items || [];
  return card("Recent logins", "last successful and failed sign-ins on this server",
    items.length
      ? `<pre class="code-out" style="max-height:50vh">${esc(items.join("\n"))}</pre>`
      : ui.emptyState(data.note || "No login records.", "users"),
    "users");
}

/* ------------------------------------------------------- 9. time sync */
async function renderTime() {
  const t = await api.get("/api/toolkit/time");
  if (!t.available) {
    return card("Time sync", "clock and NTP status", ui.emptyState(t.note, "clock") + `<div class="mono" style="text-align:center">${esc(t.local_time)}</div>`, "clock");
  }
  return card("Time sync", "clock, timezone and NTP synchronisation",
    `<div class="list">
      <div class="list-row"><div class="grow">Local time</div><div class="mono">${esc(t.local_time)}</div></div>
      <div class="list-row"><div class="grow">Timezone</div><div class="mono">${esc(t.timezone)}</div></div>
      <div class="list-row"><div class="grow">NTP synchronised</div><span class="badge ${t.ntp_synchronized ? "ok" : "warn"}">${t.ntp_synchronized ? "yes" : "no"}</span></div>
      <div class="list-row"><div class="grow">NTP service</div><div>${esc(t.ntp_service || "—")}</div></div></div>`,
    "clock");
}

/* ------------------------------------------------------- 10. runbook */
async function renderNotes() {
  const n = await api.get("/api/toolkit/notes");
  return card("Runbook notes", `saved on this server${n.updated ? ` · last edit ${timestamp(n.updated)}` : ""}`,
    `<textarea class="textarea mono" id="nt-text" rows="14" maxlength="204800" placeholder="Write your procedures, contacts and reminders here…">${esc(n.text)}</textarea>
     <div class="row" style="gap:8px;margin-top:10px"><button class="btn btn-primary" data-act="nt-save">${icon("save")}Save notes</button></div>`,
    "edit");
}

async function saveNotes() {
  await api.put("/api/toolkit/notes", { text: document.getElementById("nt-text").value });
  ui.notifyOk("Saved", "Runbook saved");
}

/* ------------------------------------------------------- wiring */
const RENDER = {
  snippets: renderSnippets, alerts: renderAlerts, report: async () => renderReport(),
  ports: renderPorts, cron: async () => renderCron(), cert: async () => renderCert(),
  disk: async () => renderDisk(), logins: renderLogins, time: renderTime, notes: renderNotes,
};

async function show(panelId, refresh = false) {
  state.panel = panelId;
  document.querySelectorAll(".tk-tab").forEach((b) => {
    const on = b.dataset.panel === panelId;
    b.classList.toggle("active", on);
    b.setAttribute("aria-selected", String(on));
  });
  const target = body();
  if (!target) return;
  clearInterval(state.pollTimer);
  if (!refresh && state.cache[panelId] !== undefined) {
    target.innerHTML = state.cache[panelId];
    return;
  }
  target.innerHTML = ui.skeletonRows(3, 56);
  try {
    const html = await RENDER[panelId]();
    state.cache[panelId] = html;
    if (state.panel === panelId) target.innerHTML = html;
  } catch (err) {
    target.innerHTML = `<div class="card">${ui.emptyState(ui.errorText(err), "alert")}</div>`;
  }
}

const ACTIONS = {
  "sn-add": () => addSnippet(),
  "sn-run": (b) => runSnippet(b.dataset.id),
  "sn-del": async (b) => {
    await api.del(`/api/toolkit/snippets/${b.dataset.id}`);
    ui.notifyOk("Deleted", "Snippet removed");
    await show("snippets", true);
  },
  "th-save": () => saveThresholds(),
  "th-refresh": () => show("alerts", true),
  "report-dl": async () => {
    try { await downloadFile("/api/toolkit/report.md"); ui.notifyOk("Ready", "Report downloaded"); }
    catch (err) { ui.showError(err, "Report failed"); }
  },
  "pf-go": () => findPort(),
  "cr-go": () => showCron(),
  "ce-go": () => checkCert(),
  "dk-go": () => scanDisk(),
  "nt-save": () => saveNotes(),
};

export default {
  title: "Toolkit",
  crumb: "snippets, alerts, reports, ports, cron, TLS, disk, logins, time, runbook",
  async mount(container) {
    state.container = container;
    state.cache = {};
    container.innerHTML = shell();
    container.addEventListener("click", async (event) => {
      const tab = event.target.closest("[data-panel]");
      if (tab) { show(tab.dataset.panel); return; }
      const btn = event.target.closest("[data-act]");
      if (!btn || !ACTIONS[btn.dataset.act]) return;
      btn.disabled = true;
      try { await ACTIONS[btn.dataset.act](btn); }
      catch (err) { ui.showError(err, "Action failed"); }
      finally { btn.disabled = false; }
    });
    await show(state.panel);
  },
  unmount() {
    clearInterval(state.pollTimer);
    state.container = null;
  },
};
