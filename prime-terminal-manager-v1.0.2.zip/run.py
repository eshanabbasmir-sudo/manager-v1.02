#!/usr/bin/env python3
"""Entry point: python3 run.py  (or `python3 -m prime`)."""
from prime.app import run

if __name__ == "__main__":
    run()
