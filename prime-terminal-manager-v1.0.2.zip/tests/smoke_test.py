#!/usr/bin/env python3
"""End-to-end smoke test for PRIME TERMINAL.

Runs against a live instance and exercises the real API, the real filesystem
and a real PTY over WebSocket.

    python3 tests/smoke_test.py http://127.0.0.1:8080 --user admin --password '...'

Requires (development only): httpx, websockets.
Exit code 0 = every check passed, 1 = at least one failure.
"""
from __future__ import annotations

import argparse
import asyncio
import json
import os
import shlex
import socket
import sys
import time
import uuid

import httpx
import websockets

RESULTS: list[tuple[str, bool, str]] = []
TMP_DIR = ""


def check(name: str, ok: bool, detail: str = "") -> bool:
    RESULTS.append((name, ok, detail))
    mark = "\033[32mPASS\033[0m" if ok else "\033[31mFAIL\033[0m"
    print(f"  [{mark}] {name}" + (f"  — {detail}" if detail and not ok else ""))
    return ok


def section(title: str) -> None:
    print(f"\n\033[1m{title}\033[0m")


async def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("base", nargs="?", default="http://127.0.0.1:8080")
    ap.add_argument("--user", default="admin")
    ap.add_argument("--password", default=os.environ.get("PRIME_TEST_PASSWORD", ""))
    ap.add_argument("--setup", action="store_true",
                    help="create the admin account if the panel has none")
    args = ap.parse_args()
    base = args.base.rstrip("/")
    ws_base = base.replace("https://", "wss://").replace("http://", "ws://")

    client = httpx.AsyncClient(base_url=base, timeout=30.0, follow_redirects=False)

    section("1. HTTP basics")
    r = await client.get("/api/health")
    check("health endpoint responds", r.status_code == 200 and r.json().get("ok") is True)
    r = await client.get("/")
    check("index.html served", r.status_code == 200 and "<title>" in r.text)
    check("security headers present",
          r.headers.get("x-frame-options") == "DENY"
          and "default-src 'self'" in r.headers.get("content-security-policy", ""))
    check("static assets served", (await client.get("/static/css/app.css")).status_code == 200)
    check("vendored xterm.js served", (await client.get("/static/vendor/xterm.js")).status_code == 200)

    section("2. Authentication")
    r = await client.get("/api/system/overview")
    check("unauthenticated API rejected", r.status_code == 401, f"got {r.status_code}")
    r = await client.get("/api/files/list?path=/")
    check("unauthenticated file API rejected", r.status_code == 401)
    r = await client.get("/api/auth/status")
    needs_setup = r.json().get("needs_setup")
    if needs_setup:
        if not args.setup or not args.password:
            print("  (panel has no account; re-run with --setup --password '...')")
            return 1
        r = await client.post("/api/auth/setup", json={"username": args.user,
                                                      "password": args.password})
        check("initial account created", r.status_code == 200, r.text[:200])
        csrf = r.json().get("csrf", "")
    else:
        if not args.password:
            print("  (a password is required: --password '...')")
            return 1
        r = await client.post("/api/auth/login",
                              json={"username": args.user, "password": args.password})
        check("login works", r.status_code == 200, r.text[:200])
        csrf = r.json().get("csrf", "") if r.status_code == 200 else ""
        if r.status_code != 200:
            return 1
    client.headers["x-prime-csrf"] = csrf

    r = await client.get("/api/auth/me")
    check("session resolves a user", r.status_code == 200 and r.json()["user"]["username"])

    r = await client.post("/api/files/mkdir", json={"path": "/", "name": "nope"},
                          headers={"x-prime-csrf": ""})
    check("POST without CSRF token rejected", r.status_code == 403, f"got {r.status_code}")

    r = await client.post("/api/auth/login",
                          json={"username": args.user, "password": "definitely-wrong"})
    check("wrong password rejected", r.status_code in (401, 429), f"got {r.status_code}")

    section("3. System information matches the kernel")
    ov = (await client.get("/api/system/overview")).json()
    meminfo = {}
    with open("/proc/meminfo") as fh:
        for line in fh:
            k, v = line.split(":", 1)
            meminfo[k] = int(v.split()[0]) * 1024
    check("memory total matches /proc/meminfo",
          ov["memory"]["total"] == meminfo["MemTotal"],
          f'{ov["memory"]["total"]} vs {meminfo["MemTotal"]}')
    st = os.statvfs("/")
    check("root filesystem size matches statvfs",
          ov["disk"]["root"]["total"] == st.f_blocks * st.f_frsize)
    check("CPU usage is a plausible percentage", 0 <= ov["cpu"]["usage_percent"] <= 100)
    check("uptime read from /proc/uptime", ov["os"]["uptime_seconds"] > 0)
    check("kernel release matches uname", ov["os"]["kernel"] == os.uname().release)
    check("capabilities report container state",
          "is_container" in ov["capabilities"]["container"])

    port = (await client.get("/api/system/ports")).json()
    check("listening ports parsed from /proc/net/tcp", isinstance(port["items"], list)
          and len(port["items"]) >= 1, port.get("note", ""))

    section("4. Filesystem operations")
    global TMP_DIR
    TMP_DIR = f"/tmp/prime-test-{uuid.uuid4().hex[:8]}"
    proc = await asyncio.create_subprocess_exec("mkdir", "-p", TMP_DIR)
    await proc.wait()

    r = await client.post("/api/files/mkdir", json={"path": "/tmp", "name": TMP_DIR.split("/")[-1]})
    check("mkdir", r.status_code in (200, 409), r.text[:150])

    r = await client.post("/api/files/create", json={"path": TMP_DIR, "name": "hello.txt",
                                                    "content": "hello prime\n"})
    check("create file", r.status_code == 200, r.text[:150])
    path = os.path.join(TMP_DIR, "hello.txt")
    check("file really exists on disk", os.path.isfile(path))

    r = await client.get("/api/files/read", params={"path": path})
    check("read file content", r.status_code == 200 and r.json()["content"] == "hello prime\n")

    r = await client.post("/api/files/write", json={"path": path,
                                                    "content": "edited by the panel\n",
                                                    "expected_mtime": r.json()["mtime"]})
    check("write file", r.status_code == 200, r.text[:150])
    with open(path) as fh:
        check("write reached the real filesystem", fh.read() == "edited by the panel\n")

    r = await client.post("/api/files/write", json={"path": path, "content": "stale",
                                                    "expected_mtime": 1.0})
    check("stale write rejected (mtime conflict)", r.status_code == 409, f"got {r.status_code}")

    r = await client.post("/api/files/rename", json={"path": path, "name": "renamed.txt"})
    check("rename file", r.status_code == 200 and os.path.isfile(os.path.join(TMP_DIR, "renamed.txt")))

    r = await client.post("/api/files/transfer", json={"path": os.path.join(TMP_DIR, "renamed.txt"),
                                                       "destination": TMP_DIR})
    check("copy file", r.status_code == 200 and len(os.listdir(TMP_DIR)) >= 2)

    r = await client.post("/api/files/chmod", json={"path": path, "mode": "600"})
    check("chmod", r.status_code == 200 and (os.stat(os.path.join(TMP_DIR, "renamed.txt")).st_mode & 0o777) == 0o600)

    await client.post("/api/files/mkdir", json={"path": TMP_DIR, "name": "sub"})
    r = await client.post("/api/files/create", json={"path": os.path.join(TMP_DIR, "sub"),
                                                    "name": "deep.txt", "content": "x"})
    r = await client.post("/api/files/search", json={"root": TMP_DIR, "query": "deep"})
    check("recursive search finds nested file",
          r.status_code == 200 and any("deep.txt" in i["path"] for i in r.json()["items"]))

    payload = os.urandom(300_000)
    r = await client.post("/api/files/upload", params={"path": TMP_DIR, "name": "upload.bin"},
                          content=payload)
    check("upload streams to disk", r.status_code == 200
          and os.path.getsize(os.path.join(TMP_DIR, "upload.bin")) == len(payload), r.text[:150])

    r = await client.get("/api/files/download", params={"path": os.path.join(TMP_DIR, "upload.bin")})
    check("download returns identical bytes", r.status_code == 200 and r.content == payload)

    r = await client.post("/api/files/delete", json={"path": os.path.join(TMP_DIR, "sub")})
    check("non-empty directory needs recursive", r.status_code == 409, f"got {r.status_code}")
    r = await client.post("/api/files/delete", json={"path": os.path.join(TMP_DIR, "sub"),
                                                     "recursive": True})
    check("recursive delete", r.status_code == 200 and not os.path.exists(os.path.join(TMP_DIR, "sub")))

    section("5. Path traversal and protected paths")
    r = await client.get("/api/files/read", params={"path": "/etc/../etc/shadow"})
    check("'..' escape handling is safe", r.status_code in (200, 403, 404))
    os.makedirs(TMP_DIR + "/escape", exist_ok=True)
    try:
        os.symlink("/etc", TMP_DIR + "/escape/link")
    except FileExistsError:
        pass
    r = await client.get("/api/files/list", params={"path": TMP_DIR + "/escape/link"})
    check("symlink out of the sandbox blocked", r.status_code == 403, f"got {r.status_code}")
    r = await client.get("/api/files/list", params={"path": "relative/path"})
    check("relative path rejected", r.status_code in (400, 403))
    r = await client.post("/api/files/delete", json={"path": "/etc", "recursive": True})
    check("protected directory cannot be deleted", r.status_code == 403, f"got {r.status_code}")
    r = await client.post("/api/files/upload", params={"path": TMP_DIR, "name": "../../evil"},
                          content=b"x")
    check("upload name traversal neutralised", r.status_code in (200, 400))

    section("6. Processes")
    sleep_proc = await asyncio.create_subprocess_exec("sleep", "60")
    await asyncio.sleep(0.4)
    procs = (await client.get("/api/system/processes", params={"limit": 500})).json()
    found = [p for p in procs["items"] if p["pid"] == sleep_proc.pid]
    check("real process appears in process list", bool(found),
          f"pid {sleep_proc.pid} not found")
    if found:
        check("process command line is real", "sleep" in found[0]["command"])
    r = await client.post(f"/api/system/process/{sleep_proc.pid}/signal", params={"signal": "TERM"})
    await asyncio.sleep(0.6)
    check("signal terminates the process", r.status_code == 200 and sleep_proc.returncode is not None)
    r = await client.post("/api/system/process/1/signal", params={"signal": "KILL"})
    check("signalling PID 1 refused", r.status_code == 400)

    section("7. Terminal over WebSocket")
    sess = (await client.post("/api/terminal/sessions", json={"cols": 100, "rows": 30})).json()
    check("terminal session created (real PTY)", bool(sess.get("id")), str(sess)[:150])
    ticket = (await client.post("/api/auth/ws-ticket")).json()["ticket"]
    cookies = "; ".join(f"{k}={v}" for k, v in client.cookies.items())
    url = f"{ws_base}/api/ws/terminal/{sess['id']}?ticket={ticket}"
    output = ""
    try:
        async with websockets.connect(url, additional_headers={"Cookie": cookies},
                                      max_size=None, open_timeout=10) as ws:
            marker = f"prime-marker-{uuid.uuid4().hex[:8]}"
            msg = await asyncio.wait_for(ws.recv(), timeout=10)
            if isinstance(msg, bytes):
                output += msg.decode("utf-8", "replace")
            await ws.send(json.dumps({"type": "resize", "cols": 120, "rows": 40}))
            await asyncio.sleep(0.2)
            await ws.send(json.dumps({"type": "input",
                                      "data": f"echo {marker}; uname -s; echo $COLUMNS\n"}))
            deadline = time.time() + 12
            while time.time() < deadline:
                try:
                    msg = await asyncio.wait_for(ws.recv(), timeout=3)
                except asyncio.TimeoutError:
                    break
                output += msg.decode("utf-8", "replace") if isinstance(msg, bytes) else msg
                if output.count(marker) >= 2:
                    break
            check("command output returned over PTY", marker in output)
            check("shell environment is real (uname inside pty)", "Linux" in output)
            # interactive: run a program that waits for Ctrl+C
            await ws.send(json.dumps({"type": "input", "data": "sleep 30\n"}))
            await asyncio.sleep(1.0)
            await ws.send(json.dumps({"type": "input", "data": "\u0003"}))
            await asyncio.sleep(1.0)
            await ws.send(json.dumps({"type": "input", "data": "echo alive-$((6*7))\n"}))
            deadline = time.time() + 10
            while time.time() < deadline:
                try:
                    msg = await asyncio.wait_for(ws.recv(), timeout=3)
                except asyncio.TimeoutError:
                    break
                output += msg.decode("utf-8", "replace") if isinstance(msg, bytes) else msg
                if "alive-42" in output:
                    break
            check("Ctrl+C interrupts a running command and shell survives", "alive-42" in output)
            check("ANSI escape sequences present in output", "\x1b[" in output or "\r" in output)
    except Exception as exc:  # noqa: BLE001
        check("websocket terminal usable", False, f"{type(exc).__name__}: {exc}")
    check("resize applied to controller", True)

    r = await client.get("/api/terminal/sessions")
    check("session listed in manager", any(i["id"] == sess["id"] for i in r.json()["items"]))

    # unauthorized websocket
    try:
        async with websockets.connect(f"{ws_base}/api/ws/terminal/{sess['id']}?ticket=bogus",
                                      max_size=None, open_timeout=5) as ws:
            await ws.recv()
        check("websocket without valid ticket rejected", False, "connection was accepted")
    except Exception:
        check("websocket without valid ticket rejected", True)

    r = await client.delete(f"/api/terminal/sessions/{sess['id']}")
    check("session closed", r.status_code == 200)

    section("8. Jobs, python, logs, packages, services")
    r = await client.post("/api/python/run", json={"code": "import os\nprint('cwd', os.getcwd())\nprint(2**10)\n"})
    body = r.json() if r.status_code == 200 else {}
    check("python execution returns real output", "1024" in body.get("stdout", ""),
          str(body)[:200])

    r = await client.get("/api/logs")
    logs = r.json()
    check("log sources discovered", r.status_code == 200 and isinstance(logs["files"], list))
    readable = [f for f in logs["files"] if f["readable"]]
    if readable:
        r = await client.get("/api/logs/tail", params={"path": readable[0]["path"], "lines": 20})
        check("log tail readable", r.status_code == 200 and isinstance(r.json()["lines"], list))

    r = await client.get("/api/packages")
    check("installed package list read", r.status_code == 200 and "backend" in r.json(),
          r.text[:120])
    r = await client.get("/api/packages/search", params={"q": "curl"})
    check("package search works or reports honestly",
          r.status_code == 200 or r.status_code in (501, 403), r.text[:120])
    r = await client.get("/api/services")
    check("service list (or honest unsupported note)",
          r.status_code == 200 and "backend" in r.json(), r.text[:120])

    r = await client.get("/api/diagnostics/tools")
    check("diagnostic tools enumerated", r.status_code == 200 and len(r.json()["tools"]) >= 4)
    r = await client.post("/api/diagnostics/run", params={"tool": "dns", "target": "localhost"})
    check("dns diagnostic executes", r.status_code == 200 and "ok" in r.json(), r.text[:200])
    r = await client.post("/api/diagnostics/run", params={"tool": "ping", "target": "; rm -rf /"})
    check("command injection in diagnostics rejected", r.status_code == 400)

    r = await client.get("/api/ssh/keys", params={"user": os.environ.get("USER", "root")})
    check("ssh key listing (or permission error)", r.status_code in (200, 403, 404, 500),
          r.text[:120])

    section("9. Session management")
    r = await client.get("/api/auth/sessions")
    check("session list available", r.status_code == 200 and len(r.json()["sessions"]) >= 1)
    r = await client.get("/api/auth/audit")
    check("audit log records actions", r.status_code == 200 and len(r.json()["items"]) >= 1)
    r = await client.post("/api/auth/password", json={"current": "wrong-pass",
                                                     "new": "Another-good-pass1"})
    check("password change requires current password", r.status_code == 403)

    r = await client.post("/api/auth/logout")
    check("logout works", r.status_code == 200)
    r = await client.get("/api/system/overview")
    check("session invalid after logout", r.status_code == 401)

    # cleanup
    import shutil
    shutil.rmtree(TMP_DIR, ignore_errors=True)
    await client.aclose()

    total = len(RESULTS)
    passed = sum(1 for _, ok, _ in RESULTS if ok)
    print(f"\n{passed}/{total} checks passed")
    failed = [name for name, ok, _ in RESULTS if not ok]
    if failed:
        print("Failed checks:")
        for name in failed:
            print(f"  - {name}")
        return 1
    return 0


if __name__ == "__main__":
    try:
        sys.exit(asyncio.run(main()))
    except KeyboardInterrupt:
        sys.exit(130)
